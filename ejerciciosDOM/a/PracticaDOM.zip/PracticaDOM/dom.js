

let parrafo = document.getElementById("parrafo")
console.log(parrafo);
let titulo = document.querySelector("h1")
console.log(titulo);
let parrafos = document.querySelectorAll("p")
console.log(parrafos);


parrafo.className += " parrafo2 "


let nuevoHijo = document.createElement("div")
nuevoHijo.innerHTML = '<img class="tamañoIMG" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRSEkQjS6OKTDSKWzb9ladVQlP3562fLoQxOUPdvlHDbQ&s" alt="">'

console.log(nuevoHijo);
document.querySelector("body").appendChild(nuevoHijo)

let imagen1 = document.getElementsByClassName("tamanoIMG")
console.log(imagen1[0]);

//...........
let practicaParrafo = document.getElementById("parrafo")
console.log(practicaParrafo);

practicaParrafo.className = "cambioParrafo"

document.querySelector("div").removeChild(document.getElementById("parrafo"))

let nuevoHijo2 = document.createElement("div")
nuevoHijo2.innerHTML = '<img class="tamanoIMG" src="https://cdn.hobbyconsolas.com/sites/navi.axelspringer.es/public/media/image/2020/05/gta-vi-1947857.jpg" alt="">'
console.log(nuevoHijo2);

document.querySelector("body").replaceChild(nuevoHijo2,nuevoHijo)

document.querySelector("body").className = "hola"
document.querySelector("body").classList.add("hola2")
document.querySelector("body").classList.remove("hola")
document.querySelector("body").classList.toggle("hola3")




let imagenCambiar = document.getElementById("imagenEliminar")
console.log(imagenCambiar);

imagenCambiar.addEventListener("mouseover",function(){
    imagenCambiar.setAttribute("src","https://graffica.ams3.digitaloceanspaces.com/2024/04/logo-queen-1975-colores-1.png")
    
})

imagenCambiar.addEventListener("mouseout",function(){
    imagenCambiar.setAttribute("src","https://image.api.playstation.com/vulcan/ap/rnd/202010/0114/b4Q1XWYaTdJLUvRuALuqr0wP.png")
    
})









